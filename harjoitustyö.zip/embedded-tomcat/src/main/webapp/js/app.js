	async function removeProduct(id) {
		// let response = await fetch(`/niilespuuntiheys2/database?id=${id}`, { method: "DELETE" });
		let response = await fetch("/WEB-INF/pro?id=" + id , { method: "DELETE"});
		
		if (response.status === 200) {
			let element = document.getElementById("item-" + id);
			element.remove();
		} else {
			alert("Something went wrong.");
		}
	}