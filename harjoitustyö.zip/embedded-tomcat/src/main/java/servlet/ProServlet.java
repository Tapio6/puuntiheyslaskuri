package servlet;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BalsalevyDAO;
import database.JDBCBalsalevyDAO;
import model.Balsalevy;

@WebServlet("/pro")
public class ProServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		BalsalevyDAO balsalevyDAO = new JDBCBalsalevyDAO();

		req.setAttribute("items", balsalevyDAO.getAllItems());
		req.getRequestDispatcher("/WEB-INF/pro.jsp").forward(req, resp);

	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		BalsalevyDAO balsalevyDAO = new JDBCBalsalevyDAO();

		try {
			// jaetaan 1000, jotta saadaan tulos millimetreinä
			double paksuus = Double.valueOf(req.getParameter("paksuus")) / 1000;
			double pituus = Double.valueOf(req.getParameter("pituus")) / 1000;
			double leveys = Double.valueOf(req.getParameter("leveys")) / 1000;
			double paino = Double.valueOf(req.getParameter("paino")) / 1000;
			String grain = req.getParameter("grain");
			double tiheys = (paino / (paksuus * pituus * leveys));

			Balsalevy balsalevy = new Balsalevy(tiheys, paksuus, leveys, paino, pituus, grain);
			balsalevyDAO.addItem(balsalevy);

			resp.sendRedirect("/pro");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}