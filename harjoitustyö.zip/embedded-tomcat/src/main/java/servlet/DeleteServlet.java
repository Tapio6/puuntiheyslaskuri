package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BalsalevyDAO;
import database.JDBCBalsalevyDAO;
import model.Balsalevy;

@WebServlet("/DeleteServlet")

public class DeleteServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		BalsalevyDAO balsalevyDAO = new JDBCBalsalevyDAO();
		int id = Integer.valueOf(req.getParameter("id"));
		Balsalevy toDelete = balsalevyDAO.getItem(id);
		balsalevyDAO.removeItem(toDelete);
		resp.sendRedirect("/pro");
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		doGet(req, resp);
	}
}
