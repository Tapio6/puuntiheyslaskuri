package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Balsalevy;

public class JDBCBalsalevyDAO implements BalsalevyDAO {

	private static final String URL = "jdbc:sqlite:C:\\sqlite\\balsalevy.sqlite";

	@Override
	public List<Balsalevy> getAllItems() {
		List<Balsalevy> items = new ArrayList<Balsalevy>();
		Database database = new Database();
		Connection connection = database.connect();
		try {

			PreparedStatement statement = connection.prepareStatement("SELECT * FROM Balsalevy");
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				Balsalevy item = new Balsalevy();
				item.setId(results.getInt("id"));
				item.setTiheys(results.getDouble("tiheys"));
				item.setGrain(results.getString("grain"));
				item.setPaksuus(results.getDouble("paksuus"));
				item.setLeveys(results.getDouble("leveys"));
				item.setPituus(results.getDouble("pituus"));
				item.setPaino(results.getDouble("paino"));

				items.add(item);
			}
			results.close();
			statement.close();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return items;
	}

	@Override
	public Balsalevy getItem(int id) {
		Balsalevy item = new Balsalevy();

		try {
			Class.forName("org.sqlite.JDBC");
			Connection connection = DriverManager.getConnection(URL);
			String sql = "SELECT * FROM Balsalevy;";
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				System.out.println("TAPIO " + results.getString("id"));
				long intId = results.getInt("id");
				if (intId == results.getInt("id")) {
					System.out.println("LÖYTYI");
					item.setId(results.getInt("id"));
					item.setTiheys(results.getDouble("tiheys"));
					item.setGrain(results.getString("grain"));
					item.setPaksuus(results.getDouble("paksuus"));
					item.setLeveys(results.getDouble("leveys"));
					item.setPituus(results.getDouble("pituus"));
					item.setPaino(results.getDouble("paino"));

				}
			}
			results.close();
			statement.close();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return item;
	}

	@Override
	public boolean addItem(Balsalevy newItem) {
		int id = 0;

		for (Balsalevy levy : this.getAllItems()) {
			if (levy.getId() > id) {
				id = levy.getId();
			}
		}
		id++;
		Database database = new Database();

		try {
			Class.forName("org.sqlite.JDBC");
			Connection connection = DriverManager.getConnection(URL);
			String sql = "INSERT INTO Balsalevy VALUES(?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = connection.prepareStatement(sql);

			statement.setInt(1, id);
			statement.setDouble(2, newItem.getTiheys());
			statement.setDouble(3, newItem.getPaksuus());
			statement.setDouble(4, newItem.getLeveys());
			statement.setDouble(5, newItem.getPaino());
			statement.setDouble(6, newItem.getPituus());
			statement.setString(7, newItem.getGrain());

			statement.executeUpdate();

			statement.close();
			connection.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public boolean removeItem(Balsalevy item) {
		Database database = new Database();

		try {

			Class.forName("org.sqlite.JDBC");
			Connection connection = DriverManager.getConnection(URL);
			String sql = "DELETE FROM Balsalevy WHERE id = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, item.getId());

			statement.executeUpdate();

			statement.close();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

}
